import sqlite3
import os
import sys
import json
from werkzeug.security import generate_password_hash

DB_PATH = os.path.join(os.path.dirname(__file__), "pydah_skillpath.db")

def init_database(reset=False, db_target=None):
    target_path = db_target or DB_PATH
    if reset and os.path.exists(target_path):
        try:
            os.remove(target_path)
            print("Removed previous database for clean rebuild.")
        except Exception as e:
            print(f"Notice during reset: {e}")

    conn = sqlite3.connect(target_path)
    cursor = conn.cursor()

    # Enable foreign keys
    cursor.execute("PRAGMA foreign_keys = ON;")

    # 1. Users Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT CHECK(role IN ('student', 'admin')) NOT NULL DEFAULT 'student',
        department TEXT DEFAULT 'Computer Science & Engineering',
        year_or_designation TEXT DEFAULT '3rd Year B.Tech',
        target_role TEXT DEFAULT 'Full Stack Software Engineer',
        avatar_seed TEXT DEFAULT 'pydah_student',
        karma_xp INTEGER DEFAULT 450,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 2. Career Tracks
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS career_tracks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        title TEXT NOT NULL,
        tagline TEXT NOT NULL,
        category TEXT NOT NULL,
        icon TEXT NOT NULL,
        badge_color TEXT NOT NULL,
        estimated_hours INTEGER DEFAULT 60,
        demand_level TEXT DEFAULT 'Very High'
    );
    """)

    # 3. Modules / Roadmap Steps with Granular Checkpoints
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS modules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        track_id INTEGER NOT NULL,
        step_number INTEGER NOT NULL,
        title TEXT NOT NULL,
        tier TEXT CHECK(tier IN ('Fundamentals', 'Core Building', 'Advanced & Cloud', 'Capstone & Industry Readiness')) NOT NULL,
        description TEXT NOT NULL,
        key_skills TEXT NOT NULL,
        resources TEXT NOT NULL,
        project_prompt TEXT,
        checkpoints_json TEXT DEFAULT '[]', -- Array of sub-topics
        FOREIGN KEY (track_id) REFERENCES career_tracks(id) ON DELETE CASCADE
    );
    """)

    # 4. User Module Progress (with checked items tracking)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS user_progress (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        module_id INTEGER NOT NULL,
        status TEXT CHECK(status IN ('not_started', 'in_progress', 'completed')) DEFAULT 'not_started',
        completed_checkpoints_json TEXT DEFAULT '[]',
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, module_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE
    );
    """)

    # 5. Quizzes / Assessments
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS quizzes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        track_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        question TEXT NOT NULL,
        options_json TEXT NOT NULL,
        correct_index INTEGER NOT NULL,
        explanation TEXT,
        points INTEGER DEFAULT 25,
        FOREIGN KEY (track_id) REFERENCES career_tracks(id) ON DELETE CASCADE
    );
    """)

    # 6. User Quiz Attempts
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS quiz_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        track_id INTEGER NOT NULL,
        score INTEGER NOT NULL,
        total_questions INTEGER NOT NULL,
        passed INTEGER CHECK(passed IN (0, 1)) NOT NULL,
        attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (track_id) REFERENCES career_tracks(id) ON DELETE CASCADE
    );
    """)

    # 7. Student Projects Portfolio
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        track_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        summary TEXT NOT NULL,
        tech_stack TEXT NOT NULL,
        github_url TEXT,
        live_demo_url TEXT,
        status TEXT CHECK(status IN ('Draft', 'Under Review', 'Verified & Approved')) DEFAULT 'Verified & Approved',
        endorsement_remarks TEXT DEFAULT 'Verified by Pydah Innovation Cell. Excellent code cleanliness and architecture.',
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (track_id) REFERENCES career_tracks(id) ON DELETE CASCADE
    );
    """)

    # 8. Placement Opportunities & Internships
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS placements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company TEXT NOT NULL,
        role TEXT NOT NULL,
        track_code TEXT NOT NULL,
        package_or_stipend TEXT NOT NULL,
        package_category TEXT DEFAULT 'Dream', -- 'Standard', 'Dream' (>7LPA), 'Super Dream' (>10LPA)
        location TEXT NOT NULL,
        required_skills TEXT NOT NULL,
        deadline TEXT NOT NULL,
        eligibility TEXT NOT NULL,
        apply_link TEXT DEFAULT '#'
    );
    """)

    # 9. Technical Interview Flashcards Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS interview_flashcards (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        track_code TEXT NOT NULL,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        difficulty TEXT CHECK(difficulty IN ('Core', 'Medium', 'Advanced')) DEFAULT 'Core',
        key_concept TEXT NOT NULL
    );
    """)

    conn.commit()

    # Seed Default Users & Campus Leaderboard Peers
    demo_pass_hash = generate_password_hash("pydah123")
    users_data = [
        ("Venkata Sai Teja", "student@pydah.edu.in", demo_pass_hash, "student", "Computer Science & Engineering", "3rd Year B.Tech", "Full Stack Cloud Architect", "sai_teja", 880),
        ("Pydah SkillPath Administrator", "admin@pydah.edu.in", demo_pass_hash, "admin", "Pydah Group Dean Office", "Director of Placement Training", "Platform Administrator", "dean_pydah", 1500),
        ("K. Ananya Reddy", "ananya.r@pydah.edu.in", demo_pass_hash, "student", "Artificial Intelligence & DS", "Final Year B.Tech", "AI Research Engineer", "ananya", 920),
        ("M. Rahul Varma", "rahul.v@pydah.edu.in", demo_pass_hash, "student", "Computer Science & Engineering", "Final Year B.Tech", "Cloud DevOps Specialist", "rahul", 780),
        ("S. Sneha Latha", "sneha.l@pydah.edu.in", demo_pass_hash, "student", "Information Technology", "3rd Year B.Tech", "Full Stack Developer", "sneha", 740),
        ("Ch. Tarun Kumar", "tarun.k@pydah.edu.in", demo_pass_hash, "student", "Electronics & Communication", "3rd Year B.Tech", "Embedded IoT Architect", "tarun", 690)
    ]

    for name, email, pw, role, dept, yr, target, seed, karma in users_data:
        cursor.execute("""
            INSERT OR IGNORE INTO users (name, email, password_hash, role, department, year_or_designation, target_role, avatar_seed, karma_xp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (name, email, pw, role, dept, yr, target, seed, karma))

    # Seed Tracks
    tracks_data = [
        ("FSD", "Full Stack Web & Cloud Architect", "Master frontend frameworks, scalable microservices, databases, and automated cloud deployments.", "Software Engineering", "code-2", "#ea580c", 90, "Very High"),
        ("AIML", "Artificial Intelligence & Generative AI", "From Python foundations and Deep Learning to Vector Databases, Transformers, and LLM RAG pipelines.", "AI & Data Science", "sparkles", "#f59e0b", 110, "Explosive"),
        ("DEVOPS", "Cloud Native, DevOps & Site Reliability", "Build resilient CI/CD pipelines, Docker containers, Kubernetes clusters, and Terraform infrastructure.", "Cloud Infrastructure", "cloud", "#0ea5e9", 85, "High"),
        ("CYBER", "Cybersecurity & Ethical Penetration Testing", "Defensive network engineering, OWASP security, threat intelligence, and vulnerability remediation.", "Information Security", "shield-check", "#ef4444", 80, "Critical"),
        ("APP", "Mobile App Development (Flutter & React Native)", "Cross-platform mobile applications, reactive state management, device hardware APIs, and store releases.", "Mobile Engineering", "smartphone", "#10b981", 75, "High")
    ]

    for code, title, tagline, cat, icon, color, hrs, demand in tracks_data:
        cursor.execute("""
            INSERT OR IGNORE INTO career_tracks (code, title, tagline, category, icon, badge_color, estimated_hours, demand_level)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (code, title, tagline, cat, icon, color, hrs, demand))

    conn.commit()

    cursor.execute("SELECT id, code FROM career_tracks")
    track_map = {row[1]: row[0] for row in cursor.fetchall()}

    # Seed Modules with Sub-Checkpoints for Granular Mastery
    fsd_modules = [
        (track_map["FSD"], 1, "HTML5 Semantic Architecture & Modern CSS3 Layouts", "Fundamentals", 
         "Master semantic HTML elements, CSS Flexbox, CSS Grid, mobile-first responsive design, and DevTools debugging.", 
         "HTML5, CSS Flexbox, CSS Grid, Responsive Design, CSS Variables", 
         "https://developer.mozilla.org/en-US/docs/Web/HTML", 
         "Build a responsive multi-page institutional tech club portal.",
         json.dumps(["HTML5 Semantic Structure (<header>, <main>, <article>)", "CSS Flexbox Navigation & Alignment", "CSS Grid 12-Column Responsive Layouts", "Mobile Breakpoints & Media Queries", "Chrome DevTools Layout Inspection"])),

        (track_map["FSD"], 2, "JavaScript Deep Dive & Asynchronous Programming", "Fundamentals", 
         "ES6+ syntax, scope, closures, event loop, Promises, Fetch API, and asynchronous state handling.", 
         "ES6+, Promises, Async/Await, Web Storage, REST APIs", 
         "https://javascript.info", 
         "Develop an interactive real-time weather & telemetry dashboard with live API feeds.",
         json.dumps(["ES6 Destructuring, Spread Operator & Arrow Functions", "Closures, Lexical Scope & Hoisting", "Promises and Async / Await Patterns", "Fetch API Integration & JSON Parsing", "DOM Event Delegation & Microtask Queue"])),

        (track_map["FSD"], 3, "Backend Development with Python & RESTful APIs", "Core Building", 
         "API design patterns, Flask framework, JSON serialization, routing, error handling, and middleware.", 
         "Python, Flask, REST APIs, JSON, Postman, MVC Architecture", 
         "https://flask.palletsprojects.com", 
         "Create a modular campus resource management REST API with complete endpoints.",
         json.dumps(["Flask Application Factory & Blueprint Routing", "HTTP Methods (GET, POST, PUT, DELETE) and Status Codes", "JSON Request Parsing & Error Handling Middleware", "CORS Configuration & Postman Endpoint Testing"])),

        (track_map["FSD"], 4, "Relational Databases & Data Modeling (SQLite/PostgreSQL)", "Core Building", 
         "Schema normalization (1NF-3NF), indexing, transactions, ACID properties, and relational query optimization.", 
         "SQL, Relational Modeling, Query Optimization, Foreign Keys, Indexing", 
         "https://www.sqlite.org/docs.html", 
         "Design a student gradebook & attendance relational schema with analytic queries.",
         json.dumps(["Relational Schema Design & Foreign Key Cascades", "Multi-table JOINs, GROUP BY & Window Aggregations", "ACID Transactions & Connection Pooling", "B-Tree Indexing Optimization"])),

        (track_map["FSD"], 5, "Authentication, Security & OWASP Best Practices", "Advanced & Cloud", 
         "Password hashing algorithms (bcrypt/argon2), session tokens, JWT, CORS, CSRF, and rate limiting.", 
         "Auth Flow, Werkzeug Security, OWASP Top 10, Data Encryption", 
         "https://owasp.org/www-project-top-ten/", 
         "Implement a secure multi-role access control gateway.",
         json.dumps(["PBKDF2 / Bcrypt Password Hashing with Salt", "Session Management vs Stateless JWT", "SQL Injection Mitigation via Prepared Queries", "Cross-Site Scripting (XSS) Sanitization"])),

        (track_map["FSD"], 6, "Docker Containerization & Production Deployment", "Advanced & Cloud", 
         "Containerizing full-stack apps with Dockerfile, multi-stage builds, reverse proxies, and cloud hosting.", 
         "Docker, Docker Compose, Nginx, CI/CD, Cloud Hosting", 
         "https://docs.docker.com", 
         "Containerize the backend and frontend into production-grade multi-container setups.",
         json.dumps(["Multi-stage Dockerfile Authoring", "Container Port Mapping & Volume Mounts", "Gunicorn Production WSGI Tuning", "Cloud Deployment on Render / Railway"])),

        (track_map["FSD"], 7, "Pydah Enterprise Capstone Project", "Capstone & Industry Readiness", 
         "End-to-end production application complete with automated testing, CI pipeline, monitoring, and live demo.", 
         "Full Stack Integration, Cloud Deployment, Code Quality, Portfolio Ready", 
         "https://github.com", 
         "Publish an enterprise-ready campus placement & grievance resolution portal.",
         json.dumps(["Full Stack System Architecture Design", "Relational Database Migration Suite", "Automated API Unit Testing", "Live Deployment & GitHub Portfolio Documentation"]))
    ]

    aiml_modules = [
        (track_map["AIML"], 1, "Python for Data Science, NumPy & Pandas", "Fundamentals", 
         "Vectorized operations, data cleaning, transformations, missing value imputation, and exploratory data analysis.", 
         "Python, NumPy, Pandas, Matplotlib, Seaborn", 
         "https://pandas.pydata.org", 
         "Analyze 5 years of student placement trends and generate actionable visual reports.",
         json.dumps(["NumPy Multidimensional Array Math", "Pandas DataFrames, Grouping & Filtering", "Missing Value Handling & Outlier Detection", "Exploratory Data Analysis (EDA) Visuals"])),

        (track_map["AIML"], 2, "Applied Machine Learning & Scikit-Learn", "Core Building", 
         "Supervised and unsupervised algorithms: Regression, Random Forests, SVM, K-Means clustering, and cross-validation.", 
         "Scikit-Learn, Feature Engineering, Hyperparameter Tuning, Metrics", 
         "https://scikit-learn.org", 
         "Train an end-to-end model predicting student semester retention with 90%+ accuracy.",
         json.dumps(["Feature Scaling & One-Hot Encoding", "Classification (Random Forest, Logistic Regression)", "Hyperparameter Optimization via GridSearchCV", "Precision, Recall, ROC-AUC Evaluation"])),

        (track_map["AIML"], 3, "Deep Learning Foundations with PyTorch", "Advanced & Cloud", 
         "Neural network architectures, backpropagation, activation functions, CNNs for computer vision, and transfer learning.", 
         "PyTorch, Tensors, CNNs, Transfer Learning, GPU Acceleration", 
         "https://pytorch.org/tutorials/", 
         "Build a campus smart gate system that classifies ID badges and detects helmets.",
         json.dumps(["PyTorch Tensors, Autograd & Loss Functions", "Building Multi-Layer Perceptrons (MLP)", "Convolutional Neural Networks (CNNs) for Images", "Transfer Learning with Pretrained ResNet"])),

        (track_map["AIML"], 4, "Generative AI, Large Language Models & Prompt Engineering", "Advanced & Cloud", 
         "Transformer architectures, fine-tuning, embeddings, vector databases (ChromaDB/Pinecone), and LangChain.", 
         "LLMs, Transformers, LangChain, Vector Embeddings, RAG", 
         "https://huggingface.co", 
         "Build a Pydah Knowledge Copilot that queries college syllabi and regulations using RAG.",
         json.dumps(["Transformer Attention Mechanisms & Tokens", "Vector Embeddings & Cosine Similarity Search", "LangChain Document Loaders & Chunking", "Retrieval-Augmented Generation (RAG) Architecture"])),

        (track_map["AIML"], 5, "GenAI Production Capstone & Model Deployment", "Capstone & Industry Readiness", 
         "Model serving via REST APIs, ONNX runtime, streaming responses, and monitoring drift in production.", 
         "FastAPI, ONNX, MLflow, Model Monitoring, Docker", 
         "https://huggingface.co/docs", 
         "Deploy a production AI assistant service with token usage analytics and latency graphs.",
         json.dumps(["FastAPI Endpoint for Model Serving", "Streaming SSE Responses to Web UI", "Prompt Injection Defense & Guardrails", "Production Cloud Deployment"]))
    ]

    devops_modules = [
        (track_map["DEVOPS"], 1, "Linux System Administration & Shell Scripting", "Fundamentals", 
         "Command line mastery, file permissions, processes, systemd services, SSH, and Bash automation scripts.", 
         "Linux, Bash Scripting, Cron, Systemd, Networking Basics", 
         "https://linuxjourney.com", 
         "Automate server log archiving and security audit reporting via cron scripts.",
         json.dumps(["Bash CLI Commands, Piping & Grep", "File Permissions, Sudoers & User Management", "Automating Maintenance via Cron Jobs", "SSH Keypair Security & Firewall Basics"])),

        (track_map["DEVOPS"], 2, "GitOps, Branching Strategies & GitHub Actions CI/CD", "Core Building", 
         "Trunk-based development, pull request workflows, automated unit test suites, and GitHub Action workflows.", 
         "Git, GitHub Actions, CI/CD Pipelines, Linting, Automated Tests", 
         "https://docs.github.com/actions", 
         "Create a complete automated test and build pipeline with branch protection rules.",
         json.dumps(["Git Branching & Pull Request Workflows", "GitHub Actions YAML Configuration", "Automated Linting & Unit Testing", "Continuous Deployment Triggers"])),

        (track_map["DEVOPS"], 3, "Docker & Container Orchestration with Kubernetes", "Advanced & Cloud", 
         "Pods, Deployments, Services, ConfigMaps, Ingress controllers, and Helm chart packaging.", 
         "Kubernetes (K8s), Helm, Docker, Ingress, Persistent Volumes", 
         "https://kubernetes.io/docs/", 
         "Deploy a high-availability microservice cluster on local Minikube / K3s.",
         json.dumps(["Writing Production Dockerfiles", "Kubernetes Pods, Deployments & ReplicaSets", "Cluster Services & Ingress Routing", "ConfigMaps & Secrets Management"])),

        (track_map["DEVOPS"], 4, "Infrastructure as Code with Terraform & AWS", "Capstone & Industry Readiness", 
         "Declarative cloud provisioning (VPC, EC2, S3, RDS), state management, and cloud monitoring with Prometheus/Grafana.", 
         "Terraform, AWS, CloudWatch, Prometheus, Grafana", 
         "https://developer.hashicorp.com/terraform", 
         "Provision an enterprise VPC architecture with automated zero-downtime rolling updates.",
         json.dumps(["Terraform HCL Syntax & State Management", "AWS VPC, Subnets & Security Groups Provisioning", "Prometheus Metrics Scraping & Alerts", "Grafana Service Health Dashboards"]))
    ]

    cyber_modules = [
        (track_map["CYBER"], 1, "Network Protocols, Wireshark & Threat Vectors", "Fundamentals", 
         "TCP/IP handshakes, DNS, HTTP/S, packet inspection with Wireshark, port scanning with Nmap.", 
         "Wireshark, Nmap, TCP/IP, OSI Model, Subnetting", "https://tryhackme.com", 
         "Conduct a network topology and open port security audit.",
         json.dumps(["TCP 3-Way Handshake Analysis", "DNS & ARP Poisoning Defense", "Nmap Port & Service Discovery", "Wireshark Packet Capture Filtering"])),

        (track_map["CYBER"], 2, "Web Application Penetration Testing & OWASP", "Core Building", 
         "SQL injection, XSS, CSRF, insecure direct object references, and Burp Suite interception.", 
         "Burp Suite, OWASP Top 10, SQLMap, Vulnerability Assessment", "https://portswigger.net/web-security", 
         "Execute penetration test and compile a CVSS vulnerability remediation report.",
         json.dumps(["Burp Suite Proxy Traffic Interception", "SQL Injection Exploitation & Defense", "Cross-Site Scripting (XSS) Payloads", "CVSS Vulnerability Scoring & Reporting"]))
    ]

    app_modules = [
        (track_map["APP"], 1, "Dart Language & Flutter Widget Architecture", "Fundamentals", 
         "Object-oriented Dart, Stateless & Stateful widgets, layout trees, themes, and Material 3 design.", 
         "Flutter, Dart, Widget Trees, Material 3, Responsive UI", "https://flutter.dev", 
         "Design a campus timetable and event broadcast mobile app.",
         json.dumps(["Dart Syntax, Classes & Async Streams", "Stateless vs Stateful Lifecycle", "Column, Row, Stack & Flexible Layouts", "Material Design 3 Theme Styling"])),

        (track_map["APP"], 2, "State Management & REST API Synchronization", "Core Building", 
         "State management with Riverpod/Bloc, asynchronous HTTP feeds, JSON parsing, and offline cache.", 
         "Riverpod, Bloc, REST APIs, SharedPreferences, SQLite Mobile", "https://pub.dev", 
         "Create an offline-first student project submission mobile client.",
         json.dumps(["State Management using Riverpod Providers", "HTTP REST API Integration with Dio", "Local SQLite Storage via SQFlite", "Publishing Build Artifacts for Android/iOS"]))
    ]

    all_modules = fsd_modules + aiml_modules + devops_modules + cyber_modules + app_modules

    for m in all_modules:
        cursor.execute("""
            INSERT OR IGNORE INTO modules (track_id, step_number, title, tier, description, key_skills, resources, project_prompt, checkpoints_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, m)

    conn.commit()

    # Pre-seed progress for the demo student
    cursor.execute("SELECT id FROM users WHERE email = 'student@pydah.edu.in'")
    demo_student_id = cursor.fetchone()[0]

    cursor.execute("SELECT id, checkpoints_json FROM modules WHERE track_id = ?", (track_map["FSD"],))
    fsd_module_records = cursor.fetchall()

    if len(fsd_module_records) >= 3:
        # Module 1 completed with all checkpoints
        m1_id, m1_cp = fsd_module_records[0]
        cursor.execute("""
            INSERT OR IGNORE INTO user_progress (user_id, module_id, status, completed_checkpoints_json)
            VALUES (?, ?, 'completed', ?)
        """, (demo_student_id, m1_id, m1_cp))

        # Module 2 completed
        m2_id, m2_cp = fsd_module_records[1]
        cursor.execute("""
            INSERT OR IGNORE INTO user_progress (user_id, module_id, status, completed_checkpoints_json)
            VALUES (?, ?, 'completed', ?)
        """, (demo_student_id, m2_id, m2_cp))

        # Module 3 in progress with 2 checkpoints checked
        m3_id, m3_cp = fsd_module_records[2]
        m3_list = json.loads(m3_cp) if m3_cp else []
        checked_sample = json.dumps(m3_list[:2])
        cursor.execute("""
            INSERT OR IGNORE INTO user_progress (user_id, module_id, status, completed_checkpoints_json)
            VALUES (?, ?, 'in_progress', ?)
        """, (demo_student_id, m3_id, checked_sample))

    # Seed Quizzes
    quizzes_data = [
        (track_map["FSD"], "Full Stack Fundamentals", 
         "Which HTTP status code signifies that a client request was successfully processed and created a new resource?", 
         '["200 OK", "201 Created", "204 No Content", "304 Not Modified"]', 1, 
         "HTTP 201 Created indicates the request has succeeded and led to the creation of a new resource on the server.", 25),

        (track_map["FSD"], "JavaScript Asynchronous Lifecycle", 
         "In the browser JavaScript runtime, which queue handles resolved Promises callbacks?", 
         '["MacroTask Queue", "MicroTask Queue", "Call Stack directly", "Worker Thread Buffer"]', 1, 
         "Promise callbacks (.then/.catch) and queueMicrotask run in the Microtask Queue, prioritizing over regular macrotasks like setTimeout.", 25),

        (track_map["FSD"], "Database Indexing & Performance", 
         "Why is a B-Tree index commonly utilized in relational databases over a Hash index for primary keys?", 
         '["It consumes zero disk memory", "It supports range queries (<, <=, BETWEEN) efficiently", "It executes writes faster than no index", "It automatically normalizes data to 3NF"]', 1, 
         "B-Tree indices maintain sorted order, making range queries, inequality checks, and ORDER BY queries extremely fast.", 25),

        (track_map["FSD"], "Web Application Security", 
         "Which technique provides the most resilient defense against SQL Injection attacks in web APIs?", 
         '["Sanitizing client-side input in HTML", "Using parameterized queries (prepared statements)", "Encoding text to base64 before storing", "Turning off database foreign keys"]', 1, 
         "Parameterized queries separate the query structure from user parameters, preventing input from altering the SQL statement.", 25),

        (track_map["AIML"], "Model Evaluation Metrics", 
         "In a campus medical anomaly diagnosis system where missing a positive case has severe consequences, which metric should you maximize?", 
         '["Precision", "Recall (Sensitivity)", "Specificity", "F-beta where beta=0.5"]', 1, 
         "Recall maximizes true positives and minimizes false negatives (critical in healthcare / safety).", 25),

        (track_map["AIML"], "GenAI & RAG Architecture", 
         "What is the primary role of a Vector Database in a Retrieval-Augmented Generation (RAG) system?", 
         '["Fine-tuning model weights with backprop", "Executing high-speed similarity search on text embeddings", "Compiling Python bytecode to C", "Converting audio waveforms to text"]', 1, 
         "Vector databases store dense embeddings and perform cosine/k-NN similarity searches to provide relevant context to the LLM.", 25),

        (track_map["DEVOPS"], "Docker Layer Caching", 
         "Why is it recommended in a Node or Python Dockerfile to copy requirements.txt/package.json before copying the entire source directory?", 
         '["To minimize image color depth", "To leverage Docker build layer caching and avoid redundant dependency installations", "Docker requires it for compiling", "It encrypts the dependencies"]', 1, 
         "Docker caches layers; if requirements have not changed, it skips re-downloading packages, dramatically speeding up builds.", 25)
    ]

    for q in quizzes_data:
        cursor.execute("""
            INSERT OR IGNORE INTO quizzes (track_id, title, question, options_json, correct_index, explanation, points)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, q)

    conn.commit()

    # Seed Technical Interview Flashcards
    flashcards_data = [
        ("FSD", "What is the difference between SQL and NoSQL databases, and when would you choose which?", 
         "SQL databases (PostgreSQL, SQLite) are relational, table-based, enforce rigid schemas, and guarantee ACID transactions—ideal for financial, ERP, and relational data. NoSQL databases (MongoDB, DynamoDB) are document/key-value based, offer flexible schemas and horizontal scaling, suited for rapid prototyping, real-time analytics, or unstructured documents.", 
         "Core", "Database Architecture"),

        ("FSD", "Explain the JavaScript Event Loop and the difference between Microtasks and Macrotasks.", 
         "The JavaScript engine is single-threaded. Synchronous code executes first on the Call Stack. When asynchronous operations finish, their callbacks enter queues: Microtasks (Promises, queueMicrotask) have higher priority and run immediately after the current call stack clears, before any Macrotask (setTimeout, setInterval, I/O events) executes.", 
         "Medium", "Asynchronous JavaScript"),

        ("FSD", "How do you defend against Cross-Site Request Forgery (CSRF) and Cross-Site Scripting (XSS)?", 
         "To prevent CSRF: use SameSite=Strict/Lax cookie attributes, anti-CSRF synchronizer tokens in POST requests, and custom header validation. To prevent XSS: escape/sanitize all user-generated input rendered in HTML, utilize modern UI frameworks with auto-escaping, and implement a strict Content Security Policy (CSP).", 
         "Advanced", "Web Security"),

        ("AIML", "What is the difference between Overfitting and Underfitting, and how do you mitigate Overfitting?", 
         "Overfitting occurs when a model learns training data noise and fails to generalize (low train loss, high val loss). Underfitting occurs when the model is too simple to capture patterns. Mitigate overfitting using L1/L2 regularization, dropout layers, cross-validation, data augmentation, early stopping, and pruning.", 
         "Core", "Machine Learning"),

        ("AIML", "Walk through how Retrieval-Augmented Generation (RAG) works from prompt to response.", 
         "1. Input: User submits a query. 2. Embed: Query is converted into a high-dimensional vector. 3. Retrieve: Vector DB performs cosine/k-NN similarity search on document chunks. 4. Augment: Relevant chunks are injected into the LLM system prompt as context. 5. Generate: The LLM produces a grounded, hallucination-free answer with exact citations.", 
         "Advanced", "Generative AI"),

        ("DEVOPS", "What is the difference between a Container (Docker) and a Virtual Machine (VM)?", 
         "A Virtual Machine virtualizes hardware and runs a full guest operating system on top of a Hypervisor, taking gigabytes and minutes to boot. A Docker Container shares the host OS kernel and isolates processes using Linux namespaces and cgroups, making it megabytes in size, starting in milliseconds, and consuming far less RAM.", 
         "Core", "Containerization"),

        ("DEVOPS", "What are the key differences between Kubernetes Deployment, Service, and Ingress?", 
         "Deployment manages Pod lifecycles, replicas, and rolling zero-downtime updates. Service provides a stable internal IP and load balances traffic across ephemeral Pods. Ingress acts as the smart HTTP/HTTPS reverse proxy routing external client domains and paths to the appropriate internal Services.", 
         "Medium", "Kubernetes Orchestration")
    ]

    for f in flashcards_data:
        cursor.execute("""
            INSERT OR IGNORE INTO interview_flashcards (track_code, question, answer, difficulty, key_concept)
            VALUES (?, ?, ?, ?, ?)
        """, f)

    # Seed Projects for Demo Student
    projects_data = [
        (demo_student_id, track_map["FSD"], "Pydah Smart Campus Resource Tracker", 
         "A unified cloud dashboard tracking seminar hall bookings, laboratory hardware status, and live student attendance using responsive layouts and REST APIs.",
         "Python, Flask, SQLite, Vanilla CSS, Chart.js",
         "https://github.com/pydah-student/smart-campus-tracker",
         "https://smartcampus.pydah.edu.in",
         "Verified & Approved",
         "Commendable architectural separation between data access and presentation layers. Approved by Pydah Innovation Cell.")
    ]

    for p in projects_data:
        cursor.execute("""
            INSERT OR IGNORE INTO projects (user_id, track_id, title, summary, tech_stack, github_url, live_demo_url, status, endorsement_remarks)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, p)

    # Seed Placement Opportunities with Package Categories
    placements_data = [
        ("TCS Digital / Prime", "Systems Engineer - Full Stack", "FSD", "₹ 7.5 - 9.0 LPA", "Dream", "Hyderabad / Bengaluru", "Python, React/Vanilla JS, REST APIs, SQL, Git", "15 Oct 2026", "B.Tech CSE/IT/ECE (60%+ in 10th, 12th, B.Tech)", "https://careers.tcs.com"),
        ("Amazon Web Services (AWS)", "Cloud Support Associate", "DEVOPS", "₹ 14.5 LPA", "Super Dream", "Hyderabad", "Linux, Docker, Networking, Cloud fundamentals, Scripting", "28 Oct 2026", "Graduating Cohort 2026/2027", "https://amazon.jobs"),
        ("Cognizant GenC Elevate", "Full Stack Developer", "FSD", "₹ 5.5 - 6.5 LPA", "Standard", "Visakhapatnam / Chennai", "HTML5, CSS3, JavaScript, Relational DB, Clean Code", "05 Nov 2026", "All B.Tech Streams", "https://careers.cognizant.com"),
        ("Infosys Springboard Hub", "AI & Data Science Analyst", "AIML", "₹ 8.0 - 9.5 LPA", "Dream", "Bengaluru / Pune", "Python, Pandas, Scikit-Learn, Deep Learning, SQL", "12 Nov 2026", "7.0+ CGPA with Verified Projects", "https://infosys.com/careers"),
        ("Qualcomm India", "Embedded Firmware Engineer", "APP", "₹ 12.0 - 16.0 LPA", "Super Dream", "Hyderabad", "C/C++, RTOS, Microcontrollers, Protocols (I2C/SPI)", "20 Nov 2026", "ECE / EEE / CSE with hardware capstone", "https://qualcomm.com/careers")
    ]

    for p in placements_data:
        cursor.execute("""
            INSERT OR IGNORE INTO placements (company, role, track_code, package_or_stipend, package_category, location, required_skills, deadline, eligibility, apply_link)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, p)

    conn.commit()
    conn.close()
    print("Database pydah_skillpath.db successfully initialized with checkpoints, leaderboard, and flashcards!")

if __name__ == "__main__":
    do_reset = "--reset" in sys.argv or "-r" in sys.argv
    init_database(reset=do_reset)
